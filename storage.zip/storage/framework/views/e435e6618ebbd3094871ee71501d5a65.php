<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="<?php echo e(asset('css/StoryLogin/halaman5.css')); ?>" />
  <title>Portal Login</title>
</head>
<body>
    <div class="login-image">
        <div class="speech-bubble">
        Tapi jangan salah, ini bukan sekadar menyusun laporan atau menyelesaikan skripsi biasa. Ini adalah perjalanan panjang untuk membuktikan bahwa kamu layak menyandang gelar Archmage Sejati.      <span class="arrow"></span>
        </div>
        <p class="next-text">Klik manapun untuk berikutnya</p>
    </div>
</body>
<script>
    document.querySelector('.login-image').addEventListener('click', function() {
        window.location.href = '<?php echo e(route('halaman6')); ?>';
    });
</script>
</html>
<?php /**PATH C:\Users\TUF\RPL_UAS\resources\views\storylogin\halaman5.blade.php ENDPATH**/ ?>