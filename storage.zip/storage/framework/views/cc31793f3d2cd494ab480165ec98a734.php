<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard BIMA</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/Dashboard/style.css')); ?>" />
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
        <img src="<?php echo e(asset('images/Dashboard/logo-bima.png')); ?>" alt="Logo BIMA" class="logo" />
        <nav class="menu">
            <a href="<?php echo e(route('homepage')); ?>" class="active"><img src="<?php echo e(asset('images/Dashboard/icon-dashboard.png')); ?>" alt="Icon Dashboard" /> Dashboard</a>
            <a href="<?php echo e(route('peta.peta1')); ?>"><img src="<?php echo e(asset('images/Dashboard/icon-peta.png')); ?>" alt="Icon Peta" /> Peta</a>
            <a href="<?php echo e(route('mentoring.index')); ?>"><img src="<?php echo e(asset('images/Dashboard/icon-mentoring.png')); ?>" alt="Icon Mentoring" /> Mentoring</a>
            <a href="<?php echo e(route('peringkat')); ?>"><img src="<?php echo e(asset('images/Dashboard/icon-peringkat.png')); ?>" alt="Icon Peringkat" /> Peringkat</a>
            <a href="<?php echo e(route('library')); ?>"><img src="<?php echo e(asset('images/Dashboard/icon-library.png')); ?>" alt="Icon Library" /> Library</a>
        </nav>
        <a class="logout" href="<?php echo e(route('login')); ?>"><img src="<?php echo e(asset('images/Dashboard/icon-logout.png')); ?>" alt="Icon LogOut" /> Logout</a>
        </aside>

        <main class="main">
            <header>
                <h2>Selamat Datang, <?php echo e(auth()->user()->fullname ?? auth()->user()->name); ?>!</h2>
                <div class="top-right-icons">
                    <button class="icon-button">
                        <i class="fa-solid fa-bell"></i>
                    </button>
                    <a href="<?php echo e(route('profile')); ?>"><img src="<?php echo e(asset('images/Dashboard/profile-dashboard.jpg')); ?>" alt="Profile" class="profile-image" /></a>
                </div>
            </header>

        <section class="level-section">
            <div class="level-card">
            <div class="level-text">
                <span class="level-badge">Level <?php echo e(auth()->user()->level); ?> - <?php echo e(auth()->user()->level_name); ?></span>
                <div class="level-progress"><small><?php echo e(auth()->user()->xp); ?>/<?php echo e(auth()->user()->xp_for_next_level); ?></small></div>
            </div>
            <img src="<?php echo e(asset('images/Dashboard/bg-dashboard.png')); ?>" alt="Portal" class="portal-bg" />
            <img src="<?php echo e(asset('images/Dashboard/k-bima-dashboard.png')); ?>" alt="Karakter" class="character" />
            <div class="ranking-box">
                <table class="ranking-table">
                <thead>
                    <tr>
                    <th>Rank</th>
                    <th>Nama</th>
                    <th>Level</th>
                    <th>Konsistensi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rankingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rank['rank']); ?></td>
                        <td><?php echo e($rank['name']); ?></td>
                        <td><?php echo e($rank['level']); ?></td>
                        <td><?php echo e($rank['consistency']); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr class="you">
                        <td><?php echo e($userRank); ?></td>
                        <td><?php echo e(auth()->user()->fullname ?? auth()->user()->name); ?></td>
                        <td><?php echo e(auth()->user()->level); ?></td>
                        <td>100%</td>
                    </tr>
                    </tbody>
            </table>
        </div>

            <section class="cards">
                <div class="card event">
                    <strong>📢 Event mendatang!</strong>
                    <p>Seminar Proposal Batch Mei – Pendaftaran dibuka hingga 28 Mei!</p>
                </div>
                <div class="card history">
                    <strong>🗝️ Riwayat Bimbingan</strong>
                    <?php $__empty_1 = true; $__currentLoopData = $mentoringHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="history-item" style="padding: 10px 0;">
                            <p style="margin: 0;">
                                <strong><?php echo e(\Carbon\Carbon::parse($item->proposed_date)->translatedFormat('d F Y')); ?> <?php echo e(\Carbon\Carbon::parse($item->proposed_time)->format('H.i')); ?> WIB</strong>
                                <br />
                                <?php echo e($item->topic); ?> - <span style="font-weight: bold;"><?php echo e($item->status); ?></span>
                            </p>
                        </div>
                        <?php if(!$loop->last): ?>
                            <hr style="border: 0; height: 1px; background-color: #eeeeee; margin: 0;">
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>Belum ada riwayat bimbingan.</p>
                    <?php endif; ?>

                    <?php if(isset($mentoringHistory) && $mentoringHistory->isNotEmpty()): ?>
                        <a href="<?php echo e(route('mentoring.1')); ?>" style="display: block; text-align: center; margin-top: 10px; font-weight: bold; text-decoration: none; color: #007bff;">
                            Lihat Semua
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card quest">
                    <strong>🪄 Quest</strong>
                    <p>Beri nama tongkat sihirmu</p>
                    <form action="<?php echo e(route('dashboard.completeQuest')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit">+10XP</button>
                    </form>
                </div>
            </section>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\TUF\RPL_UAS\resources\views\homepage.blade.php ENDPATH**/ ?>