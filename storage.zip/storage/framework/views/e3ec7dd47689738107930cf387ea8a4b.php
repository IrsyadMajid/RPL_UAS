<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard BIMA</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Mentoring/mentoringDraft1.css')); ?>" />
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
            <img src="<?php echo e(asset('images/Peta/logo-bima.png')); ?>" alt="Logo BIMA" class="logo" />
            <nav class="menu">
                <a href="<?php echo e(route('homepage')); ?>"><img src="<?php echo e(asset('images/Mentoring/icon-dashboard.png')); ?>" alt="Icon Dashboard" /> Dashboard</a>
                <a href="<?php echo e(route('peta.peta1')); ?>"><img src="<?php echo e(asset('images/Mentoring/icon-map.png')); ?>" alt="Icon Peta" /> Peta</a>
                <a href="<?php echo e(route('mentoring.index')); ?>" class="active"><img src="<?php echo e(asset('images/Mentoring/icon-bimbingan.png')); ?>" alt="Icon Mentoring" /> Mentoring</a>
                <a href="<?php echo e(route('peringkat')); ?>"><img src="<?php echo e(asset('images/Mentoring/icon-peringkat.png')); ?>" alt="Icon Peringkat" /> Peringkat</a>
                <a href="<?php echo e(route('library')); ?>"><img src="<?php echo e(asset('images/Mentoring/icon-library.png')); ?>" alt="Icon Library" /> Library</a>
            </nav>
            <a class="logout" href="<?php echo e(route('login')); ?>"><img src="<?php echo e(asset('images/Mentoring/icon-logout.png')); ?>" alt="Icon Log Out" /> Logout</a>
        </aside>

        <main class="main">
        <header>
            <div class="top-right-icons">
                <button class="icon-button"><i class="fa-solid fa-bell"></i></button>
                <button class="icon-button"><i class="fa-solid fa-comment-dots"></i></button>
                <img src="<?php echo e(asset('images/Mentoring/profile-dashboard.jpg')); ?>" alt="Profile" class="profile-image" />
            </div>
        </header>

        <div class="wrapper">
            <div class="mentoring-card">
            <div class="section-title">
                <h3>Yang akan datang</h3>
            </div>
            <?php $__empty_1 = true; $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentoring): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="mentoring-item">
                <div class="mentoring-left">
                    <div>
                        <img src="<?php echo e(asset('images/Mentoring/icon-buku.png')); ?>" alt="Book Icon" style="width: 18px; height: 18px;" />
                    </div>
                    <div class="text-wrapper">
                        <p class="mentoring-title"><?php echo e($mentoring->topic); ?></p>
                        <p class="mentoring-time">
                        <?php echo e(\Carbon\Carbon::parse($mentoring->proposed_date)->format('d M Y - H:i')); ?> (<?php echo e($mentoring->jenis_bimbingan); ?>)
                        </p>
                    </div>
                </div>
                <span class="claimed-tag">+40 XP</span>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="empty-message">Tidak ada jadwal bimbingan yang akan datang.</p>
            <?php endif; ?>

            <div class="section-title">
                <h3>Riwayat Bimbingan</h3>
            </div>

            <div class="mentoring-list">
                <?php $__empty_1 = true; $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mentoring): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mentoring-item">
                    <div class="mentoring-left">
                        <div class="icon-wrapper">
                            <img src="<?php echo e(asset('images/Mentoring/icon-buku.png')); ?>" alt="Book Icon" style="width: 18px; height: 18px;" />
                        </div>
                        <div class="text-wrapper">
                            <p class="mentoring-title"><?php echo e($mentoring->topic); ?></p>
                            <p class="mentoring-time">
                                <?php echo e(\Carbon\Carbon::parse($mentoring->proposed_date)->format('d M Y')); ?> - (<?php echo e($mentoring->jenis_bimbingan); ?>)
                            </p>
                        </div>
                    </div>
                    <?php if($mentoring->status == 'Menunggu'): ?>
                            <span class="status-tag pending">Menunggu</span>
                        <?php elseif($mentoring->status == 'Ditolak'): ?>
                            <span class="status-tag rejected">Ditolak</span>
                        <?php else: ?>
                            <span class="status-tag claimed">Terklaim</span>
                        <?php endif; ?>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="empty-message">Belum ada riwayat bimbingan.</p>
                <?php endif; ?>
            </div>
        </div>

            <div class="maskot-wrapper">
            <img src="<?php echo e(asset('images/Mentoring/k-bima.png')); ?>" alt="maskot" class="maskot" />
                <div id="chat-bubble" class="chat-bubble">
                    Sudah mulai banyak sesi telah kamu lalui, merupakan satu langkah lebih dekat menuju gelar magister pengetahuan. Teruslah melangkah, jangan lengah!
                </div>
            </div>
        </div>
        <a href="<?php echo e(route('mentoring.draft')); ?>" class="mentoring-submit">Ajukan Jadwal Mentoring</a>
        </main>
    </div>

    <script>
        const texts = [
        "Sudah mulai banyak sesi telah kamu lalui, merupakan satu langkah lebih dekat menuju gelar magister pengetahuan. Teruslah melangkah, jangan lengah!",
        "Jangan lupa unggah bukti mentoring agar pencapaianmu tercatat dengan baik!",
        "Setiap langkah kecil hari ini, adalah lompatan besar di masa depan!"
        ];

        let currentIndex = 0;
        const bubble = document.getElementById("chat-bubble");

        function updateBubbleText() {
        bubble.style.opacity = 0;
        setTimeout(() => {
            bubble.textContent = texts[currentIndex];
            bubble.style.opacity = 1;
            currentIndex = (currentIndex + 1) % texts.length;
        }, 500);
        }

        setInterval(updateBubbleText, 10000);
        window.onload = updateBubbleText;
    </script>
</body>
</html>
<?php /**PATH C:\Users\TUF\RPL_UAS\resources\views\mentoring\mentoringDraft1.blade.php ENDPATH**/ ?>