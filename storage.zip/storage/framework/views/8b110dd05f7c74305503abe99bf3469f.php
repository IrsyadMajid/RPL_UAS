<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard BIMA</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Mentoring/mentoring2.css')); ?>" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
        <img src="<?php echo e(asset('images/Peta/logo-bima.png')); ?>" alt="Logo BIMA" class="logo" />
                <nav class="menu">
                <a href="<?php echo e(route('homepage')); ?>"
                    ><img src="<?php echo e(asset('images/Mentoring/icon-dashboard.png')); ?>" alt="Icon Dashboard" /> Dashboard</a
                >
                <a href="<?php echo e(route('peta.peta1')); ?>"
                    ><img src="<?php echo e(asset('images/Mentoring/icon-map.png')); ?>" alt="Icon Peta" /> Peta</a
                >
                <a href="<?php echo e(route('mentoring.index')); ?>" class="active"
                    ><img src="<?php echo e(asset('images/Mentoring/icon-bimbingan.png')); ?>" alt="Icon Mentoring" /> Mentoring</a
                >
                <a href="<?php echo e(route('peringkat')); ?>"
                    ><img src="<?php echo e(asset('images/Mentoring/icon-peringkat.png')); ?>" alt="Icon Peringkat" /> Peringkat</a
                >
                <a href="<?php echo e(route('library')); ?>"
                    ><img src="<?php echo e(asset('images/Mentoring/icon-library.png')); ?>" alt="Icon Library" /> Library</a
                >
                </nav>
                <a class="logout" href="<?php echo e(route('login')); ?>"
                ><img src="<?php echo e(asset('images/Mentoring/icon-logout.png')); ?>" alt="Icon Log Out" /> Logout</a
                >
        </aside>

        <main class="main">
            <header>
                <div class="top-right-icons">
                <button class="icon-button"><i class="fa-solid fa-bell"></i></button>
                <img src="<?php echo e(asset('images/Mentoring/profile-dashboard.jpg')); ?>" alt="Profile" class="profile-image" />
                </div>
            </header>

            <div class="page-header">
                <button class="back-button">
                    <img src="<?php echo e(asset('images/Mentoring/icon-back.png')); ?>" alt="Kembali" />
                </button>
            </div>

            <div class="pengajuan-wrapper">
            <h2 class="pengajuan-title">Pilih Pengajuan Mentoring</h2>
                <div class="pengajuan-options">
                    <div id="review" class="option-card">
                    <img src="<?php echo e(asset('images/Mentoring/review-draf.png')); ?>" alt="Review Draft" />
                    <p>Review Draft</p>
                    </div>
                    <div id="offline" class="option-card">
                    <img src="<?php echo e(asset('images/Mentoring/meet-offline.png')); ?>" alt="Offline Meet" />
                    <p>Offline Meet</p>
                    </div>
                    <div id="online" class="option-card">
                    <img src="<?php echo e(asset('images/Mentoring/meet-online.png')); ?>" alt="Online Meet" />
                    <p>Online Meet</p>
                </div>
            </div>
        </main>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        console.log('Script loaded');

        function navigateTo(routeName) {
            console.log('Attempting to navigate to:', routeName);
            try {
                window.location.href = '<?php echo e(url('')); ?>' + routeName;
            } catch (e) {
                console.error('Navigation error:', e);
            }
        }

        document.querySelector('#review')?.addEventListener('click', () => {
            navigateTo('/mentoring/ajukan-draft');
        });

        document.querySelector('#offline')?.addEventListener('click', () => {
            navigateTo('/mentoring/ajukan-meet');
        });

        document.querySelector('#online')?.addEventListener('click', () => {
            navigateTo('/mentoring/ajukan-meet');
        });

        document.querySelector('.back-button')?.addEventListener('click', () => {
            navigateTo('/mentoring/list');
        });
    });
</script>
</body>
</html>
<?php /**PATH C:\Users\TUF\RPL_UAS\resources\views\mentoring\mentoring2.blade.php ENDPATH**/ ?>