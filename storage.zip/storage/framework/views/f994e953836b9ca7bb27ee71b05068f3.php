<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin Bimbingan - BIMA</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Dosen_Bimbingan/style.css')); ?>" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <aside class="sidebar">
        <img src="<?php echo e(asset('images/Dosen_Dashboard/logo-bima.png')); ?>" alt="Logo BIMA" class="logo" />
        <nav class="menu">
        <a href="<?php echo e(route('admin.a-dashboard')); ?>"><img src="<?php echo e(asset('images/Dosen_Dashboard/icon-dashboard.png')); ?>" alt="" /> Dashboard</a>
        <a href="<?php echo e(route('admin.a-mahasiswa')); ?>"><img src="<?php echo e(asset('images/Dosen_Dashboard/icon-mahasiswa.png')); ?>" alt="" /> Mahasiswa</a>
        <a href="<?php echo e(route('admin.a-bimbingan')); ?>" class="active"><img src="<?php echo e(asset('images/Dosen_Dashboard/icon-bimbingan.png')); ?>" alt="" /> Bimbingan</a>
        </nav>
        <a class="logout" href="<?php echo e(route('login')); ?>"><img src="<?php echo e(asset('images/Dosen_Dashboard/icon-logout.png')); ?>" alt="" /> Logout</a>
        </aside>

        <main class="main">
            <header>
                <div></div>
                <div class="top-right-icons">
                <button class="icon-button"><i class="fa-solid fa-bell"></i></button>
                <img src="<?php echo e(asset('images/Dosen_Mahasiswa/dashboard-profile.png')); ?>" alt="Profile" class="profile-image" />
                </div>
            </header>

            <section class="mahasiswa-section">
                <h2>Daftar Permintaan Bimbingan</h2>
                <div class="total-box">
                    <div>
                        <div>Total Permintaan</div>
                        <h1><?php echo e($requests->count()); ?></h1>
                    </div>
                    <img src="<?php echo e(asset('images/Dosen_Bimbingan/icon-totalmahasiswa.png')); ?>" alt="icon" />
                </div>

                <div class="table-container">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>NPM</th>
                                <th>Nama</th>
                                <th>Tanggal Pengajuan</th>
                                <th>Topik/Keperluan</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($request->user->npm ?? 'N/A'); ?></td>
                                <td><?php echo e($request->user->name ?? 'N/A'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($request->proposed_date)->format('d M Y')); ?></td>
                                <td>
                                    <a href="#" onclick="showAlasan('<?php echo e($request->user->name); ?>', '<?php echo e($request->user->npm); ?>', `<?php echo e($request->topic); ?>`)">Lihat Alasan</a>
                                </td>
                                <td>
                                    <?php if($request->status == 'Diterima'): ?>
                                    <span class="status accepted"><?php echo e($request->status); ?></span>
                                    <?php elseif($request->status == 'Ditolak'): ?>
                                    <span class="status rejected"><?php echo e($request->status); ?></span>
                                    <?php else: ?>
                                    <span class="status pending"><?php echo e($request->status); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($request->status == 'Menunggu'): ?>
                                    <form action="<?php echo e(route('admin.bimbingan.approve', $request->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="action-button approve">✔️</button>
                                    </form>
                                    <form action="<?php echo e(route('admin.bimbingan.reject', $request->id)); ?>" method="POST" style="display: inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" class="action-button reject">❌</button>
                                    </form>
                                    <?php else: ?>
                                    -
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" style="text-align: center;">Tidak ada permintaan bimbingan.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </main>
    </div>
    <script>
        function showAlasan(nama, npm, isi) {
            document.getElementById('alasanNama').textContent = nama;
            document.getElementById('alasanNPM').textContent = npm;
            document.getElementById('alasanIsi').textContent = isi;
            document.getElementById('alasanModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
    </script>
</body>
</html>
<?php /**PATH C:\Users\TUF\RPL_UAS\resources\views\admin-bimbingan\a-bimbingan.blade.php ENDPATH**/ ?>